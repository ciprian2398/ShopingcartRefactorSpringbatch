create trigger BI_KIDS
  before insert
  on KIDS
  for each row
  begin   
  if :NEW."NAME" is null then 
    select "KIDS_SEQ".nextval into :NEW."NAME" from dual; 
  end if; 
end;
/

